﻿

BLOB

https://abestorage2.blob.core.windows.net/


キュー

https://abestorage2.queue.core.windows.net/


テーブル

https://abestorage2.table.core.windows.net/



ファイル

https://abestorage2.file.core.windows.net/


